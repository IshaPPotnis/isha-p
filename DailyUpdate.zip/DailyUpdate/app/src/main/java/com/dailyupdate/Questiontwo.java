package com.dailyupdate;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

public class Questiontwo extends AppCompatActivity {

    Button b1,b2,b3,b4;
    int score;

    ProgressBar pb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.questiontwo);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
        {
            score=bundle.getInt("score");
        }

        b1=(Button)findViewById(R.id.button1);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.button4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Questiontwo.this,Questionthree.class);
                i.putExtra("score",score);
                startActivity(i);

                Toast.makeText(Questiontwo.this, "Score is "+score, Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Questiontwo.this,Questionthree.class);
                score=score+1;
                i.putExtra("score",score);

                startActivity(i);
                Toast.makeText(Questiontwo.this, "Score is "+score, Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Questiontwo.this,Questionthree.class);
                score=score+2;
                i.putExtra("score",score);

                startActivity(i);
                Toast.makeText(Questiontwo.this, "Score is "+score, Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Questiontwo.this,Questionthree.class);
                score=score+3;
                i.putExtra("score",score);
                startActivity(i);
                Toast.makeText(Questiontwo.this, "Score is "+score, Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

} 
