package com.dailyupdate;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomePage extends AppCompatActivity {

    int score;
    Button b1;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homelayout);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
        {
            score=bundle.getInt("score");
        }

        TextView t=(TextView)findViewById(R.id.mains);
        t.setText("Your score is \n"+score+" out of 15");

        b1=(Button)findViewById(R.id.button);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(HomePage.this,MainPage.class);
                startActivity(i);
                finish();
            }
        });
    }
} 
