package com.dailyupdate;

public class TheVariables {

    public static int rating;
} 

