/** Automatically generated file. DO NOT MODIFY */
package com.poke;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}