package com.poke;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends Activity
{
	TextView tv_Product_Name, tv_Shop_name;
	String pr_nm, sh_nm;
	Button REG;
	Context ctx = this;
	int catid;
	int shopid;
	Shop s;
	Category c;
	List<Reminder> r1;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register_layout1);

		catid = getIntent().getIntExtra("catid", -1);
		shopid = getIntent().getIntExtra("shid", -1);
		
		DatabaseOperations db = new DatabaseOperations(ctx);
		s = db.getShopById(shopid);
		c = db.getCategoryById(catid);
		db.close();


		String shopname =s.sname;
		String prouctname = c.name;

		tv_Product_Name =  (TextView) findViewById(R.id.textView3);
	//	tv_Shop_name =  (TextView) findViewById(R.id.textView4);

		tv_Product_Name.setText("You want to save Reminder for "+ prouctname +" from "+ shopname+" ?");
	//	tv_Shop_name.setText(shopname);

		REG = (Button) findViewById(R.id.button1);
		REG.setOnClickListener(new OnClickListener()
		{

			public void onClick(View v)
			{
	//			pr_nm = tv_Product_Name.getText().toString();
	//			sh_nm = tv_Shop_name.getText().toString();

				DatabaseOperations db = new DatabaseOperations(ctx);
				//db.putInformation(db, pr_nm, sh_nm);
				r1=db.getReminders();
				int f=0;
				for(Reminder r:r1)
				{
					Log.d("Category ","and shop");
					if(r.catid==catid && r.shopid==shopid)
					{
						Log.d("Entered"," in if");
						f=1;
						
						Toast.makeText(RegisterActivity.this, "You already have this entry", Toast.LENGTH_SHORT).show();
						Intent intent=new Intent(RegisterActivity.this,CategoryListActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
						
					}
					else
					{
						continue;
					}
				}
				if(f==0)
				{
				db.addReminder(shopid, catid);
			//	Toast.makeText(getBaseContext(), "Registration success", Toast.LENGTH_LONG).show();

				Intent i=new Intent(RegisterActivity.this,SwipeTab.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
				}
				db.close();
			}
		});
		// finish();

	}
}
