package com.poke;

import java.util.List;

import android.app.Application;

public class PokeApplication extends Application
{
	private List<Reminder> reminderList;
	private Double currentLongitude;
	private Double currentLatitude;

	@Override
	public void onCreate()
	{
		super.onCreate();
		loadReminders();
	}

	public void loadReminders()
	{
		DatabaseOperations db = new DatabaseOperations(this);
		reminderList = db.getReminders();
	}

	public List<Reminder> getReminderList()
	{
		return reminderList;
	}

	public Double getCurrentLongitude()
	{
		return currentLongitude;
	}

	public void setCurrentLongitude(Double currentLongitude)
	{
		this.currentLongitude = currentLongitude;
	}

	public Double getCurrentLatitude()
	{
		return currentLatitude;
	}

	public void setCurrentLatitude(Double currentLatitude)
	{
		this.currentLatitude = currentLatitude;
	}

}
