package com.poke;

public class Reminder
{
	public int catid;
	public int shopid;
	public String catname;
	public String shopname;
	public double longitude;
	public double latitude;
}
