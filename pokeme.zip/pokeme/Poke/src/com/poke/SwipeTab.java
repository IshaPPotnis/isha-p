package com.poke;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.FragmentTransaction;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;



@SuppressLint("NewApi") @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH) public class SwipeTab extends FragmentActivity implements ActionBar.TabListener {

	ActionBar actionbar;
	ViewPager viewpager;
	FragmentPageAdapter ft;
	
    @TargetApi(Build.VERSION_CODES.HONEYCOMB) @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.swipe_layout);
       int exit;
        exit=getIntent().getIntExtra("exit", -1);
        if(exit==5)
        {
        	finish();
        }
        viewpager = (ViewPager) findViewById(R.id.pager);
        ft = new FragmentPageAdapter(getSupportFragmentManager());
        actionbar = getActionBar();
        
        //colouring action bar
        ActionBar bar = getActionBar();
        bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#E52B50")));
        
        getActionBar().setStackedBackgroundDrawable(new ColorDrawable(Color.parseColor("#E52B50")));
        
        
        viewpager.setAdapter(ft);
        actionbar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        actionbar.addTab(actionbar.newTab().setText("Home").setTabListener(this));
        actionbar.addTab(actionbar.newTab().setText("Settings").setTabListener(this));
        actionbar.addTab(actionbar.newTab().setText("Help").setTabListener(this));
        viewpager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
			
			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				actionbar.setSelectedNavigationItem(arg0);
			}
			
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub
				
			}
		});
    }
	@Override
	public void onTabReselected(Tab arg0, FragmentTransaction arg1) {
		// TODO Auto-generated method stub
		
	}
	@TargetApi(Build.VERSION_CODES.HONEYCOMB) @Override
	public void onTabSelected(Tab arg0, FragmentTransaction arg1) {
		
		viewpager.setCurrentItem(arg0.getPosition());
		 
		
	}
	@TargetApi(Build.VERSION_CODES.HONEYCOMB) @Override
	public void onTabUnselected(Tab arg0, FragmentTransaction arg1) {
		// TODO Auto-generated method stub
		
	}
    
}
