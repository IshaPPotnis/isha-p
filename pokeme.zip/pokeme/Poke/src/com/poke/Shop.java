package com.poke;

public class Shop
{
	public int sid;
	public String sname;
	public String address;
	public Double lng;
	public Double lat;
}
