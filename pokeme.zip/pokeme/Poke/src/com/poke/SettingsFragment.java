package com.poke;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TimePicker;

public class SettingsFragment extends Fragment  
{
	TimePicker timepicker;
	public int hour,minute;
	public long milisec;
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		View v=inflater.inflate(R.layout.settings, container, false);
		timepicker=(TimePicker) v.findViewById(R.id.timePicker);
		Button b=(Button) v.findViewById(R.id.settime);
		b.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
			   hour=timepicker.getCurrentHour();
			   minute=timepicker.getCurrentMinute();
			   milisec=hour*minute*60*1000;
			   Log.d(""+hour," "+minute+" "+milisec);
		}
		});
		return v;
	}
	

}	
	

