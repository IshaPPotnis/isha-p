package com.poke;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

public class ReminderService extends Service implements LocationListener
{
	private static final double MAX_DISTANCE = .2;
	public int h,m,s;
	public int ms;
	private static final Map<String, Long> timeMap = new HashMap<String, Long>();
	int MAX_TIME_GAP = ((2 * 60 )+ 60) * 1000;

	LocationManager lm;

	@Override
	public IBinder onBind(Intent arg0)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate()
	{
		super.onCreate();
		Log.d("POKE.ReminderService", "onCreate");
		lm = (LocationManager) getSystemService(LOCATION_SERVICE);
	}

	@Override
	public void onDestroy()
	{
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.d("POKE.ReminderService", "onDestroy");
		lm.removeUpdates(this);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		Log.d("POKE.ReminderService", "onStartCommand");
		lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 0, this);

		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public void onLocationChanged(Location location)
	{
		double longitude = location.getLongitude();
		double latitude = location.getLatitude();

		PokeApplication app = (PokeApplication) getApplication();
		app.setCurrentLongitude(longitude);
		app.setCurrentLatitude(latitude);

		Log.d("POKE.ReminderService", "Location Changed : " + longitude + ":"
				+ latitude);
		
		//calculating current time
		Calendar now=Calendar.getInstance();
		
		h=now.get(Calendar.HOUR_OF_DAY);
		m=now.get(Calendar.MINUTE);
		s=now.get(Calendar.SECOND);
		ms=now.get(Calendar.MILLISECOND);
		Log.d("hour = "," "+h);
		Log.d("min = "," "+m);
		Log.d("sec = "," "+s);
		Log.d("ms = "," "+ms);
		
		long ct =((h*60*60)+(m*60)+s)*1000;
		Log.d("current time "," " +ct);

		List<Reminder> list = ((PokeApplication) getApplication())
				.getReminderList();

		for (final Reminder r : list)
		{

			String str = r.catid + "_" + r.shopid;
			Long time = timeMap.get(str);
			if (time == null)
			{
				time = 0L;
			}
			Log.d("time", "" + time);
			Log.d("ct -time", " " + (ct - time));
			if ((ct - time) >= MAX_TIME_GAP)
			{
			if (GreatCircle.distance(latitude, longitude, r.latitude,r.longitude) < MAX_DISTANCE)
			{
					
					timeMap.put(str, ct);
					Log.d("str  "+str, " ct ="+ct);
					Intent i = new Intent(this, AlarmActivity.class);
					i.putExtra("catid", r.catid);
					i.putExtra("shid", r.shopid);
					i.putExtra("catnm", r.catname);
					i.putExtra("shopnm", r.shopname);
					i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(i);
				}
			}
		}
		
		
	}


	// notifi

	// final int NOTIF_ID = 1234;
	//
	// NotificationManager notifManager = (NotificationManager)
	// getSystemService(NOTIFICATION_SERVICE);
	// Notification note = new Notification(R.drawable.pls1, "New E-mail",
	// System.currentTimeMillis());
	//
	// PendingIntent intent = PendingIntent.getActivity(this, 0, new
	// Intent(this, AlarmActivity.class), 0);
	//
	// note.setLatestEventInfo(this, "New E-mail",
	// "You have one unread message.", intent);
	//
	// notifManager.notify(NOTIF_ID, note);
	// // notifManager.cancel(NOTIF_ID);
	//
	// Intent i=new Intent(this,AlarmActivity.class);
	// startActivity(i);
	// }

	// public static double distance(double long1,double lat1, double long2,
	// double lat2)
	// {
	// double a=(long1-long2);
	// double b=2*(lat1-lat2);
	//
	// return Math.sqrt(a*a+b*b);
	// }

	@Override
	public void onProviderDisabled(String arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void onProviderEnabled(String arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2)
	{

	}

}
