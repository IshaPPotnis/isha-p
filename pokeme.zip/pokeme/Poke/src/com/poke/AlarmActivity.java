package com.poke;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;

public class AlarmActivity extends Activity
{
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alarm_layout);
    
        final Context ctx=this;
        final int catid;
		final int shopid;
        String catnm,shopnm;
	
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
        r.play();
	
        final AlertDialog ad=new AlertDialog.Builder(this).create();
    	
        catid = getIntent().getIntExtra("catid", -1);
		shopid = getIntent().getIntExtra("shid", -1);
		catnm = getIntent().getStringExtra("shopnm");
		shopnm = getIntent().getStringExtra("catnm");
		
		ad.setTitle("Location Reminder");
		ad.setCanceledOnTouchOutside(false);
		ad.setIcon(R.drawable.ic_launcher);
		ad.setMessage("You have a reminder for "+shopnm+" from " + catnm);
			
				
		ad.setButton("Accept", new DialogInterface.OnClickListener() 
		{
	
			public void onClick(DialogInterface dialog, int which) 
			{
				DatabaseOperations db=new DatabaseOperations(ctx);
				db.deleteReminder(catid, shopid);
			
			finish();
			}
		});
			ad.setButton2("Remind Me Later", new DialogInterface.OnClickListener() {
							
				public void onClick(DialogInterface dialog, int which) {
					//Intent i=new Intent(AlarmActivity.this,SwipeTab.class);
					//i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				
					finish();
					//i.putExtra("exit", 5);

				}
			});
		
		ad.show();
		   
		}
}