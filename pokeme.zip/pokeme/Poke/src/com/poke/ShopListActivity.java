package com.poke;

import java.util.List;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ShopListActivity extends ListActivity
{
	ShopArrayAdapter aa;
	List<Shop> shopList;
	int catid;

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id)
	{
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		Shop shp = shopList.get(position);
		int shid = shp.sid;

		Intent i = new Intent(this, RegisterActivity.class);
		i.putExtra("catid", catid);
		i.putExtra("shid", shid);

		startActivity(i);
	}

	class ShopArrayAdapter extends ArrayAdapter<Shop>
	{

		public ShopArrayAdapter(Context context, int textViewResourceId)
		{
			super(context, android.R.layout.simple_list_item_2);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			if (convertView == null)
			{
				convertView = getLayoutInflater().inflate(android.R.layout.simple_list_item_2, null);
			}
			TextView tv1 = (TextView) convertView.findViewById(android.R.id.text1);
			TextView tv2 = (TextView) convertView.findViewById(android.R.id.text2);

			Shop s = getItem(position);

			PokeApplication app = (PokeApplication) getApplication();
			Double long1 = app.getCurrentLongitude();
			Double lat1 = app.getCurrentLatitude();
			if (long1 != null || lat1 != null)
			{
				double distance = GreatCircle.distance(lat1, long1, s.lat, s.lng);
				tv2.setText("Distance : " + String.format("%3.2f", distance));
			} else
			{
				tv2.setText("Distance : -");
			}

			tv1.setText(s.sname);

			return convertView;
		}

	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		catid = getIntent().getIntExtra("catid", -1);
		if (catid == -1)
			finish();

		DatabaseOperations dop = new DatabaseOperations(this);
		shopList = dop.getShops(catid);
		aa = new ShopArrayAdapter(this, android.R.layout.simple_list_item_2);
		for (Shop shop : shopList)
		{
			aa.add(shop);
		}

		setListAdapter(aa);

	}

}
