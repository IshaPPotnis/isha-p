package com.poke;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;

import com.poke.R;

@TargetApi(Build.VERSION_CODES.HONEYCOMB) public class MainActivity extends Activity
{

	private ImageView mScanner;
	private Animation mAnimation;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// splash screen
		Handler handler;
		Runnable delayRunnable;

		handler = new Handler();
		delayRunnable = new Runnable()
		{

			@Override
			public void run()
			{
				
				// linking for Second Activity
				Intent i = new Intent(getApplicationContext(), SwipeTab.class);
				startActivity(i);
				finish();
			}
		};
		handler.postDelayed(delayRunnable, 1500);
		
		Intent i=new Intent(this,ReminderService.class);
		startService(i);
		
		//animation
		mScanner = (ImageView)findViewById(R.id.img2);

        mAnimation = new TranslateAnimation(0, 0, 0,40);
        mAnimation.setDuration(500);
        mAnimation.setFillAfter(true);
        mAnimation.setRepeatCount(-1);
        mAnimation.setRepeatMode(Animation.REVERSE);
        mScanner.setAnimation(mAnimation);
        mScanner.setVisibility(View.VISIBLE);
    
        ActionBar actionBar = getActionBar();
        actionBar.hide();

	}
}
