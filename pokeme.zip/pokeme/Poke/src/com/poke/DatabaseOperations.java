package com.poke;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.poke.TableData.TableInfo1;

public class DatabaseOperations extends SQLiteOpenHelper
{
	public static final int database_version = 32;

	public DatabaseOperations(Context context)
	{
		super(context, TableInfo1.DATABASE_NAME, null, database_version);
	}

	@Override
	public void onCreate(SQLiteDatabase sdb)
	{
		Log.d("Database oprations", "Database created");

//		sdb.execSQL("create table " + TableInfo1.TABLE_NAME + "(" + TableInfo1.Product_Name + " TEXT," + TableInfo1.Shop_name + " TEXT);");
		
		sdb.execSQL("create table shop (shopid integer primary key autoincrement, name text, address text, longe6 double, late6 double)");
		sdb.execSQL("create table product_category (categoryid integer primary key autoincrement, name text)");
		sdb.execSQL("create table shopproduct (shopid integer, categoryid integer, primary key(shopid, categoryid))");
		sdb.execSQL("create table reminder (shopid integer, catid integer)");
		// ,address,longe6,late6
		
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('DMart','D-Mart,Jule,Solapur,Maharashtra.',75.913106,17.634994)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Big Bazaar','Big Bazaar,Saat Rasta,Keshav Nagar,Solapur,Mharashtra.',75.905265,17.657873)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('New DMart','New Budhwar Peth,,Solapur,Mharashtra.',75.900646,17.690187)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Reliance Market','Relaince Market,Degaon Rd,Laxmi Vishnu Chawl,Near Mari Aai Chowk,Solapur,Mharashtra.',75.885433,17.666820)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Saraswati Book Depo','Saraswati Book Store,Budhwar Peth,Solapur,Mharashtra.',75.901011,17.676905)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Pulgam Textiles','Pulgam Textiles Showroom,Daji Peth,Bhadravati Peth,Solapur,Mharashtra.',75.918137,17.671927)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Gangji Textiles','Daji Peth,Jodbasavanna Chowk,Bhadravati Peth,Solapur,Mharashtra.',75.922396,17.679985)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Bata foot wear','Bata,Siddheshwar Temple Area,Solapur,Mharashtra.',75.906380,17.659919)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Kamal accesories','Kamal NX,Hutatma Garden-Prabhat Theatre Rd,Budhwar Peth,Solapur,Mharashtra.',75.900413,17.676739)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Navneet','Navneet Book Store,Rupa Bhavani Rd,Shaniwar Peth,Solapur,Mharashtra.',75.908584,17.678314)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Huma Medical','Huma Medical Stores,South Sadar Bazaar,Solapur,Mharashtra.',75.907674,17.658530)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Bhakalo','Bhakalo Vegetables,VIP Rd,Siddheshwar Peth,Solapur,Mharashtra.',75.900705,17.663477)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Goyal Footwear','Dhanraj Goyal & sons Footwear,Navi Peth,Murarji Peth,Solapur,Mharashtra.',75.900963,17.676909)");
		
		//test app
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Pradnya Home','Shivaji Nagar ,Modi Khana ,Solapur,Mharashtra.',75.903278,17.655467)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('CM Dept','GP Computer Department,Sakhar Peth,Solapur, Maharashtra.',75.924876,17.672521)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Pricipal Office','GP solapur,Sakhar Peth,Solapur, Maharashtra.',75.923117,17.671755)");
		
		//stationery
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Modern Color Graphics','162/7, Bakle Bunlgow, Railway Lines, Old Employment Chowk, Railway Lines, Solapur, Maharashtra 413001, India',75.906389,17.659918)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Satyam Stationery','Sakhar Peth, Solapur, Maharashtra 413006',75.926366,17.664835)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Chaitrali Stationery','Sakhar Peth, Solapur, Maharashtra 413006',75.924084,17.665535)");
		
		//medical stores
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Mallikarjun Medical','Budhavar Peth, Solapur, Maharashtra.',75.904441,17.650993)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Veerbhadra Medical Stores','Plot No 2, Shop No 2,, Anand Nagar,, Vijapur Road, Solapur, Maharashtra 413004.',75.899221,17.644236)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Patanjali Ayurvedic Medical Store','Sakhar Peth, Solapur, Maharashtra 413006.',75.922300,17.666256)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Kulswamini Medical & Gen Stores','106/1, Ghongade Vasti, Bhawani Peth, Bhawani Peth, Solapur, Maharashtra 413002',75.906380,17.685285)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Dhanraj Medical & General Stores','4, A, K, Dhanraj Giraji Hospital Compound, Railway Lines, Railway Lines, Solapur, Maharashtra 413001',75.906389,17.659916)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Baliga R V Baliga Medical Stores','443, Kasba South, Kasba South, Solapur, Maharashtra 413007.',75.906390,17.659920)");
		
		//electronics
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Vansh Electronics','5/6/A,Gold Finch Peth, Mechanic Chowk, Next To Bata Showroom, Budhavar Peth, Solapur, Maharashtra 413002',75.899303,17.677262)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('SONY','Sidheshwar Peth, Solapur, Maharashtra 413001',75.907283,17.671667)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Atre Associates','NH13, Murarji Peth, Solapur, Maharashtra 413002',75.900571,17.671092)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Samsung Electronic Showrrom','Employment Chowk, Solapur, Maharashtra',75.901010,17.663754)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Bajaj Electronics Service','Murarji Peth, Solapur, Maharashtra 413002',75.898421,17.678538)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('National Electronics','14th, Yaswanth Market, Behind Cambridge Showroom, Navipeth, Solapur, Maharashtra 413007',75.907124,17.655691)");
		
		//grocery
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Lokmangal Bazaar','Solapur, Maharashtra 413002',75.897117,17.666875)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Balaji Super Shopee ','Shop No-05, Surya Complex, Vijapur Road, Opposite Hotel Saiful, Vijapur Road, South Sadar Bazar, Jawaharlal Housing Society, Keshav Nagra, Solapur, Maharashtra 413004',75.906390,17.659921)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('V.S Agrawal Kirana Shop','132, Railway Lines, Forest, Chandni Chowk, Solapur, Railway lines, Solapur, Maharashtra 413001',75.897689,17.664622)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Sai Super Market','New Paccha peth, Sakhar Peth,Solapur, Maharashtra 4130',75.927225,17.664514)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Super Bazaar','Sainath Nagar, Solapur, Maharashtra 413224',75.917565,17.639211)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Padmaja Super Market','Datta Nagar, Sakhar Peth, Solapur, Maharashtra 413005',75.921497,17.668687)");
		
		//clothes
		/*sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Ronak Collection','Navi Peth, Solapur, Maharashtra 413001',75.902443,17.676905)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Janata Collection','28, Navi Peth, South Sadar Bazar, Jawaharlal Housing Society, Keshav Nagra, Solapur, Maharashtra 413007',75.906389,17.659920)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Planet Fashion','No. 44-46, Park Stadium, Jawaharlal Housing Society, Lashkar, Solapur, Maharashtra 413003',75.912934,17.659004)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Cottonking','Shop No 6/7, H N Complex, NH13, Sidheshwar Temple Area, Solapur, Maharashtra 413001',75.900411,17.673059)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Pepe Mufti Groove','Pepe-Mufti-Groove, City Pride Building, B Wing, Near Pankha Bawadi, Old Employment Chowk, near Solapur, Maharashtra, 157, Railway Station Rd, Solapur, Maharashtra 413001',75.901407,17.662252)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Chandan Wear','Navi Peth, Solapur, Maharashtra 413001',75.902443,17.676905)");
		
		//food items
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Domino�s','Shop No.1165, Ground Floor, Millennium Square, Collector Office Road, Railway Line, Saat Rasta, Solapur, Maharashtra 413001',75.906451,17.661909)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Smokin' joes','shop no 3, silver spring, below State bank of india, branch hotgi road, A40-41, Hotgi Road, Sainath Nagar, Solapur, Maharashtra 413003',75.915561,17.642415)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Annapurna Sweets','Jule Solapur Rd, Vishal Nagar, Jule, Solapur, Maharashtra 413004',75.904709,17.638116)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Goli Vada Pav Shop','Budhavar Peth, Solapur, Maharashtra 413001',75.903897,17.676553)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('The Fish Market','Narsinh Nagar,Near D-Mart, Solapur, Jule, Solapur, Maharashtra 413004',75.913397,17.634199)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Swastik Mithai Farsaan','222, Lucky Chowk, Opposite Hutatma Garden, Solapur., Budhavar Peth, Solapur, Maharashtra 413001',75.900923,17.675760)");
		sdb.execSQL("insert into shop (name,address,longe6,late6) values ('Nuts Mithai','Budhavar Peth, Solapur, Maharashtra 413001',75.903897,17.676553)");*/
		
		// product_category category
		sdb.execSQL("insert into product_category (name) values('Grocery')");
		sdb.execSQL("insert into product_category (name) values('Medicines')");
		sdb.execSQL("insert into product_category (name) values('Clothes')");
		sdb.execSQL("insert into product_category (name) values('Accessories')");
		sdb.execSQL("insert into product_category (name) values('Cosmetics')");
		sdb.execSQL("insert into product_category (name) values('Toys')");
		sdb.execSQL("insert into product_category (name) values('Footwear')");
		sdb.execSQL("insert into product_category (name) values('Stationary')");
		sdb.execSQL("insert into product_category (name) values('Electonic Gadgets')");
		sdb.execSQL("insert into product_category (name) values('Food Items')");
		sdb.execSQL("insert into product_category (name) values('Fruits')");
		sdb.execSQL("insert into product_category (name) values('Vegetables')");
		sdb.execSQL("insert into product_category (name) values('Blankets')");
		
		sdb.execSQL("insert into product_category (name) values('Test App')");

		// shopid and categoryid
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,1)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,3)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,4)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,5)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,6)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,7)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,8)");
	
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,11)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,12)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(1,13)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,1)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,3)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,4)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,5)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,6)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,7)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,8)");
	
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,11)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,12)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(2,13)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,1)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,3)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,4)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,5)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,6)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,7)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,8)");
		
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,11)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,12)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(3,13)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,1)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,3)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,4)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,5)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,6)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,7)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,8)");
	
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,11)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,12)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(4,13)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(5,8)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(6,13)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(7,13)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(8,7)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(9,4)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(9,5)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(10,8)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(11,2)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(12,11)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(12,12)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(13,7)");
		
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(14,14)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(15,14)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(16,14)");
		
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(17,8)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(18,8)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(19,8)");
		
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(20,2)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(21,2)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(22,2)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(23,2)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(24,2)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(25,2)");
		
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(26,9)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(27,9)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(28,9)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(29,9)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(30,9)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(31,9)");
		
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(32,1)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(33,1)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(34,1)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(35,1)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(36,1)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(37,1)");
		
		/*sdb.execSQL("insert into shopproduct(shopid,categoryid) values(38,3)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(39,3)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(40,3)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(41,3)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(42,3)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(43,3)");
		
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(44,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(45,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(46,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(47,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(48,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(49,10)");
		sdb.execSQL("insert into shopproduct(shopid,categoryid) values(50,10)");*/
		
		
		Log.d("Database oprations", "Table created");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int prevVer, int curVer)
	{
		// TODO Auto-generated method stub
		try
		{
			db.execSQL("drop table  " + TableInfo1.TABLE_NAME + "");
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			db.execSQL("drop table shop");
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			db.execSQL("drop table product_category");
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			db.execSQL("drop table shopproduct");
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			db.execSQL("drop table reminder");
		} catch (Exception e)
		{
			e.printStackTrace();
		}

		onCreate(db);
	}

	public void putInformation(DatabaseOperations dop, String pname, String sname)
	{
		SQLiteDatabase SQ = dop.getWritableDatabase();

		SQ.execSQL("insert into " + TableInfo1.TABLE_NAME + " Values('" + pname + "' , '" + sname + "');");

		SQ.close();

		Log.d("Database oprations", "one raw inserted");
	}
	
	public void addReminder(int shopid, int catid)
	{
		SQLiteDatabase db = getWritableDatabase();
		db.execSQL("insert into reminder values ("+shopid+","+catid+")");
		db.close();		
	}

	public void deleteReminder(int catid,int shopid)
	{
		SQLiteDatabase db = getWritableDatabase();
		db.execSQL("delete from reminder where shopid="+shopid+" and catid="+catid);
		db.close();		
	}
	
	public List<Reminder> getReminders()
	{
		List<Reminder> list=new ArrayList<Reminder>();
		SQLiteDatabase db = getReadableDatabase();
		Cursor c=db.rawQuery("select reminder.shopid, reminder.catid, shop.name, product_category.name, shop.longe6,shop.late6 from reminder,shop,product_category where reminder.shopid=shop.shopid and reminder.catid=product_category.categoryid", new String[]{}); //db.query("reminder", null, null, null, null, null, null);
		while(c.moveToNext())
		{
			Reminder r=new Reminder();
			list.add(r);
			
			r.shopid=c.getInt(0);
			r.catid=c.getInt(1);			
			r.shopname=c.getString(2);
			r.catname=c.getString(3);
			r.longitude=c.getDouble(4);
			r.latitude=c.getDouble(5);
		}
		c.close();
		db.close();
		return list;
	}

	public List<Category> getCategories()
	{
		SQLiteDatabase db = getReadableDatabase();
		Cursor c = db.query("product_category", null, null, null, null, null, null);
		List<Category> list = new ArrayList<Category>();

		while (c.moveToNext())
		{
			Category cat = new Category();
			cat.id = c.getInt(0);
			cat.name = c.getString(1);

			list.add(cat);
		}
		c.close();
		db.close();

		return list;
	}

	public List<Shop> getShops(int catid)
	{

		SQLiteDatabase db = getReadableDatabase();
		
		Cursor c = db.rawQuery("select shop.* from shop,shopproduct where shop.shopid=shopproduct.shopid and shopproduct.categoryid=?", new String[] { String.valueOf(catid) });

		List<Shop> list = new ArrayList<Shop>();

		while (c.moveToNext())
		{
			Shop shop = new Shop();
			shop.sid = c.getInt(0);
			shop.sname = c.getString(1);
			shop.address=c.getString(2);
			shop.lng=c.getDouble(3);
			shop.lat=c.getDouble(4);
			

			list.add(shop);
		}
		c.close();
		db.close();

		return list;
	}

	public Shop getShopById(int sid)
	{
		Shop s=null;
		SQLiteDatabase db = getReadableDatabase();
		Cursor c = db.rawQuery("select * from shop where shop.shopid=?", new String[] { String.valueOf(sid) });
		if(c.moveToFirst())
		{
			s=new Shop();
			s.sid=sid;
			s.sname=c.getString(1);
			s.address=c.getString(2);
//			s.longe6=c.getLong(3);
//			s.late6=c.getLong(4);
		}
		c.close();
		db.close();
		return s;
	}
	
	public Category getCategoryById(int catid)
	{
		Category cat=null;
		SQLiteDatabase db = getReadableDatabase();
		Cursor c = db.rawQuery("select * from product_category where product_category.categoryid=?", new String[] { String.valueOf(catid) });
		if(c.moveToFirst())
		{
			cat=new Category();
			cat.id=catid;
			cat.name=c.getString(1);
		}
		c.close();
		db.close();
		return cat;

	}
}
