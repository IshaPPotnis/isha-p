package com.poke;

import java.util.List;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class HomeFragment extends Fragment 
{
	// ArrayAdapter adapter;
	ReminderArrayAdapter adapter;
	int Reminderid;
	ListView listView;
	private List<Reminder> list;
	List<Shop> shops;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO Auto-generated method stubt

		View v = inflater.inflate(R.layout.home_layout, container, false);
		listView = (ListView) v.findViewById(R.id.listView1);

		adapter = new ReminderArrayAdapter(getActivity(), android.R.layout.simple_list_item_2);

		listView.setAdapter(adapter);
		registerForContextMenu(listView);
		
		ImageButton ib1 = (ImageButton) v.findViewById(R.id.add);


		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			   @Override
			   public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

					view.showContextMenu();

			   } 
			});

		ib1.setOnClickListener(new View.OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				// TODO Auto-generated method stub
//gps notify
				LocationManager locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
				if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
			        Toast.makeText(getActivity(), "GPS is enabled in your device", Toast.LENGTH_SHORT).show();
			        Intent intent = new Intent(getActivity(), CategoryListActivity.class);
					startActivity(intent);

				}
				else{
			        showGPSDisabledAlertToUser();
					Toast.makeText(getActivity(), "GPS is disabled in your device", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		//gps on notify 
		
		return v;
	
	}


	protected void showGPSDisabledAlertToUser(){
        
		final LocationManager locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
        alertDialogBuilder.setMessage("GPS is disabled in your device. Would you like to enable it?").setCancelable(false).setPositiveButton("Enable GPS",
                new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id){
                Intent callGPSSettingIntent = new Intent(
                        android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(callGPSSettingIntent);
                
        		if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                Intent intent = new Intent(getActivity(), CategoryListActivity.class);
				startActivity(intent);
        		}
            }
        });
        alertDialogBuilder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id){
                dialog.cancel();
                
            }
        });
        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
    }

	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuinfo)
	{
		
		
		if (v.getId() == R.id.listView1)
		{
//			AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuinfo;
			menu.setHeaderTitle("");
			menu.add("Delete");
			menu.add("Details");

		}
	}
	

	public boolean onContextItemSelected(MenuItem item)
	{
		AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
		DatabaseOperations dop = new DatabaseOperations(getActivity());
		//int menuItemIndex = item.getItemId();
		if (item.getTitle()== "Delete")
		{
			int index = info.position;
			Reminder r = list.get(index);
			Toast.makeText(getActivity(), "Deleted : " + r.catname + " : " + r.shopname, Toast.LENGTH_LONG).show();
			dop.deleteReminder(r.catid, r.shopid);
			populateReminders();
		} 
		else if (item.getTitle() == "Details")
		{
				int index=info.position;
				Reminder r =list.get(index);
			//	int sid=r.shopid;
				Shop s1=dop.getShopById(r.shopid);
				
			    AlertDialog.Builder adb = new AlertDialog.Builder(
	                    getActivity());
	                    adb.setTitle("Details");
	                    adb.setMessage("\n Shop Name : "+s1.sname+" \n Shop Address : "+s1.address+"\n");
	                    adb.setPositiveButton("Ok", null);
	                    adb.show();    
		}
		else;
		{
			return false;
		}

	}
	
	class ReminderArrayAdapter extends ArrayAdapter<Reminder>
	{

		public ReminderArrayAdapter(Context context, int textViewResourceId)
		{
			super(context, android.R.layout.simple_list_item_2);
		}


		@Override
		public View getView(int position, View convertView, ViewGroup parent)

		{
			LayoutInflater inflater = LayoutInflater.from(getActivity());

			if (convertView == null)
			{
					convertView = inflater.inflate(android.R.layout.simple_list_item_2, parent, false);
			}
			TextView tv1 = (TextView) convertView.findViewById(android.R.id.text1);
			TextView tv2 = (TextView) convertView.findViewById(android.R.id.text2);

			Reminder r = getItem(position);

			tv1.setText(r.catname);
			tv2.setText(r.shopname);

			return convertView;
		}

	}

	@Override
	public void onResume()
	{
		// TODO Auto-generated method stub
		super.onResume();
		populateReminders();
	}

	private void populateReminders()
	{

		DatabaseOperations db = new DatabaseOperations(getActivity());
		list = db.getReminders();
		adapter = new ReminderArrayAdapter(getActivity(), android.R.layout.simple_list_item_2);
		for (Reminder r : list)
		{
			adapter.add(r);
		}

		listView.setAdapter(adapter);

		/*
		 * list=db.getReminders(); adapter.clear(); for(Reminder r:list) {
		 * adapter.add(r.shopname+":"+r.catname); }
		 */
		db.close();
	}

}
