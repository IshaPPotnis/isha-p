package com.poke;

public class Category
{
	public int id;
	public String name;
}
